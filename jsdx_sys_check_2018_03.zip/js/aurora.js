function DoPost(str) {
    var f = document.getElementById('DoPostForm');
    if (!f) {
        f = document.createElement('form');
        f.action=str;
        f.method="post";
        document.body.appendChild(f);
    } else {
        f.action = str;
    }
    f.submit();
}

function check24Hour(str) {
	var pattern = /^(([0-1]?[0-9])|(2[0-3])):[0-5]?[0-9]$/;

    return pattern.exec(str);
}

/*HH:MM::SS 秒可有可无，不满足10的前面补零*/
function isTime(str) {
    var pattern = /^([0-1][0-9]|[2][0-3]):([0-5][0-9])(:([0-5][0-9]))?$/;
    return pattern.exec(str);
}

/*YYYY-MM-DD*/
function isDate(str) {
    var pattern = /^[1-2][0-9]{3}-[0-1][0-9]-[0-3][0-9]$/;
    return pattern.exec(str);
}

/* YYYY-MM-DD HH:MM:SS 秒可有可无*/
function isDateAndTime(str) {
    var pattern = /^[1-2][0-9]{3}-[0-1][0-9]-[0-3][0-9] (([0-1]?[0-9])|(2[0-3])):[0-5]?[0-9]$/;
    return pattern.exec(str);
}

function isEmail(str) {
    var pattern = /^[^@]+@([-\w]+\.)+[A-Za-z]{2,4}$/;
    return pattern.exec(str);
}

function isIP(str) {
    var pattern = /^(((1?\d{1,2})|(2[0-4]\d)|(25[0-5]))\.){3}(1?\d{1,2})|(2[0-4]\d)|(25[0-5])$/;
    return pattern.test(str);

}

function isIPRange(str)
{
    var pattern = /^(((1?\d{1,2})|(2[0-4]\d)|(25[0-5]))\.){3}(((1?\d{1,2})|(2[0-4]\d)|(25[0-5]))|\*)$/;
    return pattern.exec(str);
}

//nie-add:用于匹配三种ip格式,(1)1.2.3.4  (2)1.2.*.*  (3)1.2.3.4-10
function validateIpMode(str)
{
	if(str.match("^\\d+\\.\\d+\\.\\d+\\.\\d+$")){   //(1)
		if(isIPRange(str)){
			return 1;
		}else{
			return 4;
		}
	}else{
		if(str.match("^([0-9]+|\\*)\\.([0-9]+|\\*)\\.([0-9]+|\\*)\\.([0-9]+|\\*)$")){    //(2)
			temp = str.split('.');
   			for(i=0 ; i<temp.length ; i++){
   				if(!isNaN(temp[i])){
   					if(parseInt(temp[i])<0 || parseInt(temp[i])>255)
						return 4;
   				}
   			}
			return 2;
		}else{
			if(str.match("^\\d+\\.\\d+\\.\\d+\\.\\d+-\\d+$")){   //(3)
				temp = str.split('-');
				tt = temp[0].split('.');
				extern = parseInt(temp[1]);
				for(i=0 ; i<tt.length ; i++){
					if(parseInt(tt[i])<0 || parseInt(tt[i])>255)
						return 4;
				}
				if(extern<0 || extern>255)
					return 4;
				return 3;
			}else{
				return 4;
			}
		}
	}
}

//nie-add:用于匹配一个ip是否在一个ip范围内
function validateIpArea(pattern , ip){
	//将pattern 和 ip 按模式拆解
	var key = new Array();
	var flag;
	var extern;
	var i=0;
	switch(validateIpMode(pattern)){
		case 1:
			flag = 1;
			temp = pattern.split('.');
   			for(i=0 ; i<temp.length ; i++){
   				if(!isNaN(temp[i])){
   					key[i] = parseInt(temp[i]);
   				}else{
   					key[i] = '*';
   				}
   			}
			break;
		case 2:
			flag = 2;
			temp = pattern.split('.');
   			for(i=0 ; i<temp.length ; i++){
   				if(!isNaN(temp[i])){
   					key[i] = parseInt(temp[i]);
   				}else{
   					key[i] = '*';
   				}
   			}
		break;
		case 3:
			flag = 3;
			temp = pattern.split('-');
			tt = temp[0].split('.');
			extern = parseInt(temp[1]);
			for(i=0 ; i<tt.length ; i++){
   				if(!isNaN(tt[i])){
   					key[i] = parseInt(tt[i]);
   				}else{
   					key[i] = '*';
   				}
   			}
		break;
		case 4:
			return false;
		break;
	}
	
	var key2 = new Array();
	var flag2;
	var extern2;
	switch(validateIpMode(ip)){
		case 1:
			flag2=1;
			temp = ip.split('.');
   			for(i=0 ; i<temp.length ; i++){
   				if(!isNaN(temp[i])){
   					key2[i] = parseInt(temp[i]);
   				}else{
   					key2[i] = '*';
   				}
   			}
			break;
		case 2:
			flag2 = 2;
			temp = ip.split('.');
   			for(i=0 ; i<temp.length ; i++){
   				if(!isNaN(temp[i])){
   					key2[i] = parseInt(temp[i]);
   				}else{
   					key2[i] = '*';
   				}
   			}
		break;
		case 3:
			flag2 = 3;
			temp = ip.split('-');
			tt = temp[0].split('.');
			extern2 = parseInt(temp[1]);
			for(i=0 ; i<tt.length ; i++){
   				if(!isNaN(tt[i])){
   					key2[i] = parseInt(tt[i]);
   				}else{
   					key2[i] = '*';
   				}
   			}
		break;
		case 4:
			return false;
		break;
	}
	//判断是否在指定范围内
	if(flag2 == 1 || flag2 == 2){
		if(flag == 1 || flag == 2){
			for(i=0 ; i<4 ; i++){
				if(!isNaN(key[i])){
					if(key[i] != key2[i]){
						return false;    //字段是数字，则必须相等
					}
				}
			}
		}else{
			for(i=0 ; i<3 ; i++){
				if(!isNaN(key2[i])){
					if(key[i] != key2[i]){
						return false;    //字段是数字，则必须相等
					}
				}else{
					return false;
				}
			}
			if(key2[3] == '*'){
				if(key[3] != 0 || extern != 255)
					return false;
			}else{
				if(key2[3]<key[3] ||key2[3] > extern)
					return false;
			}
		}
	}else{
		if(flag == 1){
			for(i=0 ; i<3 ; i++){
				if(key[i] != key2[i]){
					return false;    //字段是数字，则必须相等
				}
			}
			if(key[3] != extern2)
				return false;
		}else{
			if(flag == 2){
				for(i=0 ; i<3 ; i++){
					if(!isNaN(key[i])){
						if(key[i] != key2[i]){
							return false;    //字段是数字，则必须相等
						}
					}
				}
				if(key[3] != '*'){
					if(key[3] != key2[3] || key[3] != extern2)
						return false;
				}
			}else{
				for(i=0 ; i<3 ; i++){
					if(key[i] != key2[i]){
						return false;    //字段是数字，则必须相等
					}
				}
				if(key2[3]<key[3] || extern2 > extern)
					return false;
			}
		}
	}
	return true;
}

function checkNum(value, start, end) {
	var pattern = /^[1-9]?[0-9]+$/;
	if ( end <= start) {
        return pattern.exec(value);
	} else {
        return (pattern.exec(value) && (value >= start && value <= end));
	}
}


function sendRequest(url,argObj,updateArea){
	var queryString = $H(argObj).toQueryString();
	//cb = cbFunc ? cbFunc() : null;
	var myAjax = new Ajax.Updater(updateArea, url,{
		method     		: 	'post', //HTTP请求的方法,get or post 
		parameters		: 	queryString,
		asynchronous	:	true,
		onLoading  		: 	_ajaxLoading,
		onSuccess 		: 	_ajaxSuccess
		//onComplete  		: 	cb ,//回调函数/**/				
	});
}
function ajaxAction(url, argObj, ajaxCbFunc){
	var queryString = $H(argObj).toQueryString();
	new Ajax.Request(url, {
		method : 'post',
		parameters : queryString,
		asynchronous : true,
		onLoading : _ajaxLoading,
		onSuccess : _ajaxSuccess,
		onComplete : ajaxCbFunc
	});
}
function _ajaxLoading(){
	$('statusInformation').show();
	//$('responseMessage').hide();
}
function _ajaxSuccess(){
	//if(updateArea=='responseMessage') $('responseMessage').show();
	if ($('statusInformation')) setTimeout("$('statusInformation').hide();", 2000);
	//setTimeout("$('responseMessage').hide();", 3000);
}



function showByDialog(container, url){
	//TODO. show info in a dialog.
	var frameName = 'dialogFrame';
	if(window.name == frameName){
		//alert(frameName);
		window.parent.historyBar.push(url);
		window.location.href = url;
		return;
	}
	var html = '<div id="frameHistory" style="display:none"><input type="button" id="backButton" value="后退" onclick="historyBar.back()"/>&nbsp;&nbsp;&nbsp; <input type="button" id="forwardButton" value="前进" onclick="historyBar.forward()"/> </div>';
	html += '<iframe name="'+frameName+'" src="'+url+'" width="100%" height="95%" scrolling="auto" frameborder="0"></iframe>';
	container.fillByHtml(html);
	container.show();
	//window.parent.historyBar.init();
	historyBar.init();
	//window.parent.historyBar.push(url);
	historyBar.push(url);
}

// 配合js中的nmenu等操作
function unselect(menu, item) {
    var items = menu.getElementsByTagName('DIV');
    for (var i=0; i<items.length; i++) {
        if (items[i].className == 'selected')
            items[i].className = 'unselected';
    }
    item.className = 'selected';
}
function checkItem(item, flag) {
    if (flag==null) {
        if (item.length==undefined) {
            item.disabled = (item.disabled)?false:true;
        } else {
            for (var i=0; i<item.length; i++) {
                item[i].disabled=(item[i].disabled)?false:true; 
            }
        }
    } else {
        item.disabled = flag;
    }
}

function folderItem(item, flag) { 
	//console.log(item);
	//console.log(flag);
	if(typeof item != 'object') return;

    for(var k=0; k<item.length; k++) {
        if(item[k] == null) return;
    }
	
	if(typeof item.length == 'undefined'){
		// not an array?
		item.style.display = (item.style.display=='')?'none':''; 
	}else{
		// is an array?
		for (var i=0; i<item.length; i++) {
            if (flag!=null)
			    item[i].style.display=flag;
            else
			    item[i].style.display=(item[i].style.display=='')?'none':''; 
    	}
	}	
	if(!flag || typeof flag != 'object'){
		//
		return;
	}
	for (var i=0; i<flag.length; i++) {
		//flag[i].style.display=(flag[i].style.display=='')?'none':'';
		flag[i].style.display='none';
		item.style.display = '';
	}
}
//-->
//<!-- 选择
var GNewItemQueue = new Array(); // 增加
var GDecItemQueue = new Array(); // 减少

function checkedInit() {
    GNewItemQueue = new Array(); 
    GDecItemQueue = new Array();
    document.cookie = ''; // TODO: 可能需要更改，适应认证
}

function ifMultiSelected(selectItem, cb) {
    for (var i=0; i<selectItem.length; i++) {
        var o = selectItem.options[i];
        var id = o.value;
        if (o.selected) {
            if (!GNewItemQueue.inArray(id)) {
                GNewItemQueue[GNewItemQueue.length] = id; 
            }
        } else {
            if (GNewItemQueue.inArray(id)) {
                GNewItemQueue = GNewItemQueue.remove(id);
            }
        }
    }
    if (cb!=null) { 
        cb();
    }
}
function ifChecked(checkItem, id, cb) {
    if (checkItem.checked) {
        if (GDecItemQueue.inArray(id)) {
            GDecItemQueue = GDecItemQueue.remove(id);
        } else if (!GNewItemQueue.inArray(id)) {
            GNewItemQueue[GNewItemQueue.length] = id; 
        }
    } else {
        if (GNewItemQueue.inArray(id)) {
        	
            GNewItemQueue = GNewItemQueue.remove(id);
        } else if (!GDecItemQueue.inArray(id)) { // 增加
            GDecItemQueue[GDecItemQueue.length] = id; 
        }
        
    }
    // callback 函数
    if (cb!=null) { 
        cb();
    }/**/
}

function imageSwap(ob, fileName1, fileName2) { 
    if (ob.src.match(fileName1)==null) {
        ob.src = fileName1;
        return false;
    } else {
        ob.src = fileName2; 
        return true;
    }
}
//-->
//<!--cookie operation
function setCookie (name, value) {  //设置名称为name,值为value的Cookie 
        var argc = arguments.length; 
        var argv = arguments;     
        var path = (argc >= 2) ? argv[2] : '/';   
        var domain = (argc >= 3) ? argv[3] : null;   
        var secure = (argc >= 4) ? argv[4] : false;   
		str = name + "=" + value +  
        ((path == null) ? "" : ("; path=" + path)) +   
        ((domain == null) ? "" : ("; domain=" + domain)) +     
        ((secure == true) ? "; secure" : "");
        document.cookie = str;
}
function getCookie(c_name) {
    if (document.cookie.length>0) {
        c_start=document.cookie.indexOf(c_name + "=")
        if (c_start!=-1) { 
            c_start=c_start + c_name.length+1 
            c_end=document.cookie.indexOf(";",c_start)
            if (c_end==-1) c_end=document.cookie.length
            return unescape(document.cookie.substring(c_start,c_end))
        } 
    }
    return ""
}
//-->
//<!--
Array.prototype.insertAt = function(index, value) {
    var part1 = this.slice(0, index);
    var part2 = this.slice(index);
    part1.push(value);
    return(part1.concat(part2));
};
  
Array.prototype.removeAt = function(index) {
    var part1 = this.slice(0, index);
    var part2 = this.slice(index+1);
    
    return (this.length==1 && index==0)?part1:part1.concat( part2 );
};

Array.prototype.indexOf = function(val) {
    for (var i=0; i<this.length; i++) {
        if (this[i] == val) {
            return i;
        }
    }
    return -1;
};

Array.prototype.remove = function (val) {
    if (this.inArray(val)){
    	//alert(this.indexOf(val));
        return this.removeAt(this.indexOf(val));
    }
};

Array.prototype.inArray = function (value) {
    var i;
    for (i=0; i < this.length; i++) {
        if (this[i] == value) {
            return true;
        }
    }
    return false;
}; 
// -->

function jsRequrestUploadFile(elemId, action, cbFunc) {
    JsHttpRequest.query(action,
        {'file':$(elemId)},
        function(resjs, errors) {
            cbFunc(resjs)
        },
        false
    );

}

function pop(url) { window.open(url, '_blank', 'toolbar=no,resizable=yes,width=640,height=480,scrollbars=yes'); }
//}}}

//by wxh. used to show the history button.
function HistoryBar(frameName){	
	this.inUrl = new Array();
	this.popUrl = new Array();
	this.check = function(){
		//console.log(this.inUrl);
		//console.log(this.popUrl);
		if(this.inUrl.length == 1 && this.popUrl.length == 0) return;
		if(this.inUrl.length == 2 && this.popUrl.length == 0){
			$('frameHistory').show();
			$('backButton').disabled = false;
			$('forwardButton').disabled = true;
			return;
		}
		$('forwardButton').disabled = this.popUrl.length == 0 ? true : false;
		$('backButton').disabled = this.inUrl.length == 1 ? true : false;		
	}
	this.push = function(nowUrl){
		//if(!this.inUrl) this.inUrl.push($('dialogFrame').src);
		this.inUrl.push(nowUrl);
		this.check();
	}
	this.back  = function(){
		this.popUrl.push(this.inUrl.pop());
		this.check();
		history.go(-1);		
	}
	this.forward = function(){
		this.inUrl.push(this.popUrl.pop());
		this.check();
		history.go(1);		
	}
	this.init = function(){
		this.inUrl = new Array();
		this.popUrl = new Array();
	}
}

/**Add an attribute 'isSortAble="true"' to the table you want to sort. 
*  Add an attribute 'isSortAble="false"' to the col you don't want to sort. 
*  Add an attribute 'dataType="..."' to set the data type of the cols you want to sort. support: int, float, date
* @param options {'oTable':[object],'iCol':[int],'sDataType':[string]}
*/
function _convert(sValue, sDataType) {
	switch(sDataType) {
		case "ip":
			var arr = sValue.split('.');
			if(arr.length != 4) return 1;
			for(var i=0; i<4; i++){
				if(arr[i].length == 2) arr[i] = '0'+arr[i];
				else if(arr[i].length == 1) arr[i] = '00'+arr[i];
			}
			return arr.toString();
		case "int":
			return parseInt(sValue);
		case "float":
			return parseFloat(sValue);
		case "date":
			return new Date(Date.parse(sValue));
		default:
			return sValue.toString();
	}
}

function _generateCompareTRs(iCol, sDataType) {
	return  function compareTRs(oTR1, oTR2) {
		if (oTR1.cells[iCol].getAttribute("dataType")) {
			vValue1 = _convert(oTR1.cells[iCol].getAttribute("dataType"), sDataType);
			vValue2 = _convert(oTR2.cells[iCol].getAttribute("dataType"), sDataType);
		} else {
			//vValue1 = convert(oTR1.cells[iCol].firstChild.nodeValue.stripTags(), sDataType);
			vValue1 = _convert(oTR1.cells[iCol].innerHTML.stripScripts().stripTags().strip(), sDataType);
			//vValue2 = convert(oTR2.cells[iCol].firstChild.nodeValue.stripTags(), sDataType);
			vValue2 = _convert(oTR2.cells[iCol].innerHTML.stripScripts().stripTags().strip(), sDataType);
		}
		if (vValue1 < vValue2) {
			return -1;
		} else if (vValue1 > vValue2) {
			return 1;
		} else {
			return 0;
		}
	};
}

function sortTable(oTable, iCol, sDataType) {
	var oTBody = oTable.tBodies[0];
	var colDataRows = oTBody.rows;
	var aTRs = new Array;

	for (var i=0; i < colDataRows.length; i++) {
		aTRs[i] = colDataRows[i];
	}

	if (oTable.sortCol == iCol) {
		aTRs.reverse();
	} else {
		aTRs.sort(_generateCompareTRs(iCol, sDataType));
	}

	var oFragment = document.createDocumentFragment();
	for (var i=0; i < aTRs.length; i++) {
		aTRs[i].className = i%2 == 0 ? 'odd' : 'even';
		oFragment.appendChild(aTRs[i]);
	}

	oTBody.appendChild(oFragment);
	oTable.sortCol = iCol;
}


/* 端口校验函数，校验输入的端口（或多个端口是否在合法端口范围内） */
/* TODO: 不知道为什么，input为 0 时此处始终接收不到 input ，只有在调用该函数之前处理*/
function portCheck(input) {
    var argc = arguments.length; 
    var argv = arguments;     
    var botLimit = (argc >= 1) ? argv[1] : 1;
    var topLimit = (argc >= 2) ? argv[2] : 65535;

    var strArr = input.split(",");
    var numLen = strArr.length;
    for(var i=0; i < numLen; i++) {
        if(strArr[i] == "") {
            return false;
        }
        var sepArr = strArr[i].split("-");
        var numSep = sepArr.length;
        if (numSep == 1) { /*单个端口需要在范围内*/
            if(isNaN(strArr[i])) {
                return false;
            }
            if(strArr[i] > topLimit || strArr[i] < botLimit) {
                return false;
            }
        }
        else {
            if (numSep > 2){  /*输入格式错误*/
                return false;
            }
            if (isNaN(sepArr[0]) || isNaN(sepArr[1])) {
                return false;
            }
            if (sepArr[0] > sepArr[1]){  /*范围输入错误*/
                return false;
            }
            if (sepArr[0] > topLimit || sepArr[0] < botLimit) {
                return false;
            }
            if (sepArr[1] > topLimit || sepArr[1] < botLimit) {
                return false;
            }
        }
    }
    return true;
}
function BrowserType(){
        var ua = navigator.userAgent.toLowerCase();
        if (window.ActiveXObject)
            return 'ie';
        else if (document.getBoxObjectFor)
            return 'ff';
        else if (window.opera)
            return 'op';
}

