if(typeof($j) == 'undefined'){
	 $j = jQuery.noConflict();
}
$j("table.paging_table").each(function(index, ele) {
						$j(ele).addPagingBarToTable({
							records : 20,
							foldPrefix:'c-'
						});
					});
